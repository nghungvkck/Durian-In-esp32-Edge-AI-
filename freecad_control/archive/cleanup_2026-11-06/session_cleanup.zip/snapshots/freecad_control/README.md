# FreeCAD — bàn giao D36 hiện tại

Cập nhật **06/11/2026, Asia/Bangkok**. Đọc file này trước khi tiếp tục CAD. Mọi đường dẫn tương đối bên dưới tính từ gốc dự án `Duration_edge_ai`, trừ khi có ghi khác.

## 0. Hiện hành — dây đã gom gọn theo bó, 06/11

Đã sửa tuyến21 dây trong bản chính theo yêu cầu mới: dải SPI song song, bó micro và nhánh quanh mép, dây nút theo mép PCB, dây nguồn chạy lớp dưới với các đoạn song song. Giữ nguyên endpoints/net/đường kính và33 objects cơ khí/linh kiện; tổng55 objects không đổi. Hình C3 đại diện S3 Super Mini, SD3V3 và các hạn chế pin vật lý vẫn như đã chốt.

Kiểm tra21 dây với33 objects gốc và mọi cặp dây không phát hiện giao thoa ngoài vùng tiếp điểm: chỉ cho phép dây cùng net/cùng pad chồng trong bán kính1,1 mm (mốc đầu là3,2 mm); vùng tiếp điểm với linh kiện1,3 mm. Hở dây–vỏ/gờ nhỏ nhất khoảng0.242 mm. Đọc lại21 dây + hai vỏ từ BRep trong file đã lưu đều valid/một solid;33 BRep cũ trùng byte với backup trước gom, geometry/Placement đối chiếu đạt. Tổng tâm dây khoảng693.57 mm, chưa gồm dư hàn/mở vỏ.

Tài liệu/ảnh/report hiện hành: `CAD_DIR/Wiring_Tidy_2026-11-06/README.md`; backup trước gom `D36_before_tidy.FCStd` trong cùng thư mục. Giữ mốc đi dây đầu ở `Wiring_2026-11-06/` để tra lịch sử. Không sửa vỏ/linh kiện, không xuất STL, không sửa/build/flash firmware. Khi tiếp tục dùng bản chính và `resume_latest.py`; không chạy lại script dựng dây để mở CAD.

## 0.1. Lịch sử đi dây đầu — ESP32-S3, 06/11

Người dùng yêu cầu nối dây theo các README trong `firmware`, chốt **ESP32-S3 Super Mini dùng nguyên hình học/vị trí C3 làm đại diện** và **SD breakout chỉ nhận3V3**. Đã lưu21 dây trong bản CAD chính, không đổi33 hình học/placement cũ. Tổng55 objects:33 cũ + group `Wiring_D36_20261106` +21 `Wire_*`. Object `ESP32_C3` giữ tên nội bộ, Label/`BoardIdentity` ghi S3 và hình đại diện.

- SD CS/SCK/MOSI/MISO→GPIO13/12/11/10; micro SD/SCK/WS→GPIO4/5/6; ba nút→GPIO1/2/3. SD và micro dùng ESP3V3/GND, micro L/R nối GND.
- Pin→IP5306 B+/B−; đầu ra5V→công tắc→ESP5V; GND chung. GPIO7 cho LED theo firmware, nhưng assembly không có LED rời nên chưa thêm dây LED.
- Dây nguồn Ø ngoài0,90 mm, dây còn lại0,65 mm, chỉ là kích thước bố trí danh nghĩa. Tổng chiều dài tâm khoảng567,53 mm, chưa có phần dư hàn/mở vỏ.
- 21 dây và hai vỏ đọc lại từ BRep trong FCStd đã lưu đều valid/một solid. Không phát hiện giao thoa ngoài vùng đầu nối cho phép; khoảng hở dây–vỏ/gờ tối thiểu khoảng0,315 mm. Đã đối chiếu hình học và XML Placement của33 objects cũ với backup. Payload BRep có phần được ghi lại nên không gọi byte-identical.

**Tuyến dây xác nhận theo net logic; thứ tự pad của mô hình đại diện và các đầu nguồn/đầu cực danh nghĩa chưa đối chiếu bo thật.** Không dùng hình này thay sơ đồ chân vật lý để hàn. Chưa xác nhận vòng chùng/đường mở vỏ, kẹp giữ/chống rung dây, dung sai, dòng nguồn3V3, cách ly USB hoặc vận hành thật. Không sửa/build/flash firmware. Hình SD hiện có cũng chỉ là tham chiếu cơ khí cho breakout3V3 được người dùng chốt.

Chi tiết sơ đồ, danh sách21 dây, backup, ảnh và báo cáo: `CAD_DIR/Wiring_2026-11-06/README.md` (CAD_DIR ở mục2). Bản sao trước sửa `Wiring_2026-11-06/D36_before_wiring.FCStd`, hash `9c08bf20382902c3c63c73057a5198aed6180d2e375f15898e6718bc947cc806`. Vỏ không đổi, STL03/11 vẫn giữ nguyên. Phiên hiện tại mở riêng bản chính, không đóng/lưu bản `D36_AntiRattle_Battery_35x25x6` đang có thay đổi chưa lưu trong cửa sổ FreeCAD khác.

## 1. Bắt đầu phiên sau

1. Dùng đúng dự án `Duration_edge_ai`, không phải repo blog `nghungblog`.
2. Kiểm tra heartbeat của `freecad_control/easy_insert_session/status.json`. `connected: true` trong file cũ không chứng minh còn kết nối; `send.py` chỉ nhận heartbeat dưới 10 giây.
3. Kiểm tra kết nối rồi mở đúng bản D36 bằng hai lệnh dưới. Không dựng lại bằng script sửa lịch sử.

```bash
rtk proxy python3 freecad_control/easy_insert_session/send.py freecad_control/inspect_connection.py
rtk proxy python3 freecad_control/easy_insert_session/send.py freecad_control/resume_latest.py --timeout 60
```

`resume_latest.py` tìm document theo FileName, mở nếu cần, kiểm tra hai nửa valid/mỗi nửa một solid và kích thước X36/Z146, rồi hiện vỏ, vít, linh kiện và các dây tham chiếu ở tọa độ lắp. Script không đổi hình học hoặc lưu CAD; việc thay viewport/visibility có thể làm document được đánh dấu đã chỉnh trong GUI.

Nếu heartbeat cũ, chạy macro sau trong **FreeCAD Windows** rồi thử lại:

```text
D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai\freecad_control\restart_current.FCMacro
```

Macro mở D36 trước khi nối `easy_insert_session`. Macro `easy_insert_session/Connect.FCMacro` riêng có thể mở D50 khi chưa có document. Không chạy lại macro nếu cầu nối đang hoạt động và không đóng/lưu document khác. FreeCAD đã quan sát: 1.1.4, chương trình `C:/Program Files/FreeCAD 1.1/bin/FreeCAD.exe`.

## 2. Bản CAD chính và trạng thái đã chốt

**Chỉ tiếp tục file này:**

```text
3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6/D36_Printed_Retention_35x25x6.FCStd
```

Gọi thư mục chứa file là `CAD_DIR`. Tên thư mục `Printed_Retention` là tên lịch sử; bản hiện tại không có TPU.

| Mục | Trạng thái hiện hành |
|---|---|
| Vỏ | Ø36 × 146 mm, Z0…146; vách danh nghĩa 2 mm, đáy 3 mm; khoang Ø32 |
| Trục | +Y là trước; Z dọc thân; hai nửa chia tại Y0 |
| Object | 55: hai vỏ, 6 phần vít/đai ốc, 25 phần linh kiện, một group và 21 dây |
| Front / Rear | Thể tích theo báo cáo gia cố: 29340,783389 / 30828,065379 mm³ |
| Vít ghép vỏ | Ba bộ M3×30, trục Y, cùng X0, tại Z18 / Z121 / Z141 |
| Lỗ và hốc | Lỗ xuyên Ø4; hốc đầu Ø6,2, mặt tựa Y13; hốc đai ốc AF5,9, mặt tựa Y−14,1 |
| Vít / đai ốc mô hình | Đầu Ø5,5×3; đai ốc AF5,5×2,4; ren giản lược, chỉ tham chiếu, không xuất in |
| Pin | 35 theo Z × 25 theo X × 6 theo Y; X±12,5; Y−3,824074…2,175926; Z26,5…61,5 mm |
| Micro | PCB Ø13, dày 1,6 mm; IC mô hình cao 2 mm theo Y; chỉ một ngàm U dưới rộng 4 mm |
| Đã loại | Vít/lỗ/trụ M2 lệch cạnh; toàn bộ TPU/hốc TPU, preview tách, R/C rời, LED và đệm micro |
| Vật liệu | Vỏ/gờ nhựa cứng chưa chọn mác/profile; vít–đai ốc ghép vỏ kim loại được phép |

25 phần linh kiện gồm pin, microSD, IP5306, ESP32-S3 Super Mini dùng hình C3 đại diện, công tắc/chân, bo ba nút và các phần thân/chân, micro ICS43434/PCB/pads/passives. Không tự đổi kích thước linh kiện để ép vừa. Chiều cao IC micro 2 mm là yêu cầu mô hình, chưa xác nhận bằng datasheet vật thật.

**Thay đổi thân ở mốc 146 mm:** đã thêm 10 mm tại Z13, giữ công tắc/chân/cửa đáy; cụm pin/bo/micro/nút/gờ/cửa phía trên và hai vít cũ dịch Z+10, giữ kích thước và xoay. Vít dưới mới có trụ siết R4,5 gặp tại Y0. Không áp dụng tọa độ bản 136 mm vào bản hiện hành.

**Gia cố gờ đã thực hiện:** tăng lưng hai thanh pin nửa sau 0,8→1,6 mm, rộng theo Z 4→5,2 mm; chặn đầu 0,8→1,6 mm về phía ngoài pin. Mặt đỡ pin Y−4,624074 giữ nguyên. Chân thanh mở về hai vách, cắt theo R16,8. Mở chân gờ SD/ESP/bo nút nửa trước, chân IP5306/đế ngàm micro nửa sau. Không thêm khung pin đối xứng nửa trước hoặc ngàm micro bên/trên.

**Yêu cầu giữ nguyên:** SD chỉ hai giá góc đối diện, không dùng bo SD làm mặt ép pin; micro chỉ giữ một đầu; giữ linh kiện bằng chi tiết in 3D, không tự thêm keo/mút/băng dính. Mục tiêu ít gờ, đơn giản, cầm/gõ không lung lay hoặc phát tiếng chưa được xác nhận bằng thử nghiệm thực.

## 3. Hash, kiểm chứng và mức độ tin cậy

SHA-256 CAD hiện hành sau khi gom dây và lưu ngày06/11:

```text
39f39e587e6e562525fdf9370f45cbdf2783d0e3523c8590d6a385d9aaf9cb29
```

Kiểm chứng gom dây06/11 ở `CAD_DIR/Wiring_Tidy_2026-11-06/validation.json`: đọc lại21 dây và hai vỏ từ FCStd; đối chiếu33 objects nguồn với backup bằng vertices/edges/faces/volume/Placement. Các báo cáo03/11 bên dưới chỉ xác nhận hình học vỏ trước đi dây. Hash trước đi dây, đọc khi dọn tài liệu03/11:

```text
9c08bf20382902c3c63c73057a5198aed6180d2e375f15898e6718bc947cc806
```

Hash bản nguồn đã kiểm chứng gia cố và xuất STL:

```text
30ffa569b3b1985c07a908fed7001bee70d0980014a19a7e67fb60a15af345c7
```

Bản có hash nguồn còn tại `CAD_DIR/D36_Printed_Retention_35x25x6.20261103-092358.FCBak`. Đối chiếu ZIP/XML ngày 03/11: danh sách 33 objects, toàn bộ payload BRep và XML Placement trùng byte giữa CAD tại mốc03/11 (nay là backup trước đi dây) và backup này. Các mục ZIP khác là `Document.xml`, `GuiDocument.xml`, `thumbnails/Thumbnail.png`; vì vậy không gọi hai file là giống hệt nhau hoặc gán hash nguồn STL cho CAD hiện tại.

Lần dọn03/11 chỉ đọc ZIP/XML/hash, **không khởi chạy kiểm chứng BRep bằng kernel FreeCAD và không sửa/lưu CAD**. Kết quả hai vỏ valid/mỗi nửa một solid, X36/Z146, không giao thể tích và phần thêm không cấn linh kiện là kết quả đã ghi trong `CAD_DIR/Reinforced_Frame/validation.json`. Báo cáo đó ghi 31 objects ngoài vỏ giữ nguyên, khoảng hở phần thêm trên 0,19 mm theo các kiểm tra cục bộ/hộp bao. Không suy ra toàn bộ đường lắp hoặc lực giữ đều đạt từ các kiểm tra này.

Khi file thay đổi sau này, đo lại hash và kiểm tra hình học liên quan. Một ZIP mở được, hash trùng hoặc báo cáo cũ không thay thế kiểm chứng hình học mới.

## 4. STL đã xuất — dùng đúng bộ D36

Trong `CAD_DIR/Print_2026-11-03/`:

| File | Tam giác | SHA-256 |
|---|---:|---|
| `D36_Front_half_2026-11-03.stl` | 6.308 | `a22ef03c5108e645dceb502ebabb76d9f4aacc86228a0269e32caa72df422ae4` |
| `D36_Rear_half_2026-11-03.stl` | 4.416 | `fb28b9829afbdebd1c7371fa1708fe5e101627fd5579744606966499e0edb812` |

Chỉ xuất hai vỏ đã gia cố, không xuất vít/đai ốc hoặc linh kiện. STL binary, nhập theo mm vì định dạng không lưu đơn vị; giữ tọa độ lắp, chưa chọn hướng in. Độ lệch tuyến tính 0,05 mm, góc 0,15 rad. Báo cáo xuất đã đọc lại hai mesh closed solid, X36/Z146, sai lệch thể tích với BRep dưới 0,12%. Xem README và `validation.json` trong thư mục xuất.

Chưa slicer/G-code/profile/hướng in/support/in thử. Không dùng ước lượng 4–7 giờ của bản cũ làm thời gian in bản hiện tại. `Front_half_no_ribs.stl` ở gốc dự án là **D50**, không phải D36.

## 5. Bằng chứng và các việc chưa hoàn thành

Các thư mục sau trong `CAD_DIR` giữ nguyên backup, JSON kiểm chứng và ảnh của từng mốc:

| Thư mục | Ý nghĩa |
|---|---|
| `Wiring_Tidy_2026-11-06/` | Tuyến hiện hành đã gom theo bó, backup/validation/ảnh; thứ tự pad vật lý chưa xác nhận |
| `Wiring_2026-11-06/` | Mốc đi dây đầu đã thay tuyến; giữ backup/validation/ảnh |
| `Reinforced_Frame/` | Gia cố gờ hiện hành; `validation.json`, `reinforced_frame.png`, backup trước gia cố |
| `Centered_Lower_M3/` | Thân 146 mm, ba M3 thẳng hàng; `three_aligned_M3.png`, backup/validation |
| `Print_2026-11-03/` | Hai STL D36 và báo cáo xuất |
| `Simplified_Holder_Steps/` | Bỏ hốc/khe TPU; mốc trước thân146 |
| `Selected_Components/` | Phục hồi 25 phần linh kiện; mốc trước thân146 |
| `Shells_Only/`, `Assembled_View/`, `Lower_Screw/` | Mốc cũ, không phải hiện trạng |
| `Recessed_Fasteners/`, `Micro_Single_End/`, `SD_Simplification/` | Lịch sử vít âm/ngàm micro/giá SD |

README trong `CAD_DIR` còn có các đoạn lịch sử nối tiếp nhau. Không dùng các dòng “mới nhất”, “chỉ 6 objects”, “TPU”, “136 mm”, “chưa xuất STL” hoặc hash cũ ở đó để thay thế trạng thái tổng hợp của tài liệu này. Đọc báo cáo theo đúng mốc.

Các phần chưa được xác nhận:

- Dung sai in, lực siết, độ bền, lực giữ pin/bo, chống xoay micro và khả năng cầm/lắc/gõ không phát tiếng.
- Đường lắp/tháo, mở vỏ, tháo SD, đầu cáp, anten ESP32, nhiệt và yêu cầu âm học.
- Dây D36 đã có tuyến3D danh nghĩa ngày06/11; còn thiếu đối chiếu pad thật, phần dư hàn/mở vỏ, đường lắp/tháo, kẹp giữ/chống rung/cách điện và chọn dây thực. Không mang dây D50 sang.
- Slicer/G-code/profile/máy/vật liệu/hướng in/support và in/lắp thử.

Không tự triển khai dây/firmware, sửa CAD hoặc xuất lại khi người dùng chỉ yêu cầu tài liệu. Mô hình ESP nay đại diện S3 theo người dùng; firmware và việc build/flash/kiểm thử vẫn là việc riêng, không thực hiện trong tác vụ CAD.

## 6. Quy tắc vận hành cầu nối

- Lệnh shell luôn có tiền tố `rtk`. Python Linux chỉ gửi script/đọc ZIP/XML, **không chạy mã FreeCAD CAD trên Linux**.
- Giữ ba cầu nối: gốc `freecad_control`, `easy_insert_session`, `open_tray_session`. Phiên tiếp tục D36 dùng `easy_insert_session`; không tự đổi cầu nối.
- Timeout không hủy request. Kiểm tra UUID trong inbox/outbox trước khi gửi lại; request có response không được phát lại.
- Script mới tự chứa imports/biến; không phụ thuộc namespace của phiên trước. Khởi động lại FreeCAD sẽ mất globals cũ.
- Request đã ngắt `easy_insert_session/interrupted_requests/5b496b93493148eba884d5f52b136a9d.json` chỉ giữ để tra cứu, không chuyển về inbox. Script `finish_recessed_fasteners.py` lịch sử từng treo ở phép Boolean đối chiếu toàn assembly, không chạy lại.
- Khi dọn hàng đợi chỉ xóa request đã có response hợp lệ, xóa request trước rồi response. Luôn giữ request chưa hoàn tất. Các cặp lỗi còn lại dùng để tra cứu, không chạy lại tự động.

## 7. Quy tắc sửa CAD ở phiên sau

Sao lưu trước khi sửa. Chỉ sửa phần được yêu cầu, giữ kích thước/placement phần ngoài phạm vi. Trước lưu: kiểm tra valid, số solid, `optimalBoundingBox(False, False)`, giao thoa liên quan và viewport; sau lưu đọc lại BRep. Tránh Boolean đối chiếu toàn assembly gần giống nhau gây treo. IP5306 có dạng mặt: `common.Volume == 0` riêng lẻ không chứng minh không cấn, cần xét khoảng cách/diện tích giao.

`removeSplitter()` từng tạo shape lỗi, chỉ áp dụng nếu kết quả hợp lệ. Dùng Shaded để tránh nhầm đường chia mặt với gờ nhựa; Shaded không xóa cạnh hình học. Đợi camera ổn định trước chụp; import `from pivy import coin` nếu thao tác camera node.

Khi chốt thay đổi CAD, cập nhật README này và README bản CAD tương ứng. Không tự sửa `.gitignore`, commit/push hoặc xóa CAD/backup/lịch sử. Giữ các thay đổi firmware, tài liệu Word và repo blog ngoài phạm vi.

## 8. File giữ lại và lịch sử đã dọn

Các script lập tuyến/dựng/lưu/đọc lại và chụp dây ngày06/11 được liệt kê trong README của `CAD_DIR/Wiring_Tidy_2026-11-06/` và mốc trước `Wiring_2026-11-06/`; không tự chạy lại để mở phiên. Các file vận hành giữ ở thư mục chính: `Connect.FCMacro`, `send.py`, `inspect_connection.py`, `resume_latest.py`, `restart_current.FCMacro`; ba script `resume_compact_d36.py`, `resume_compact_layout.py`, `resume_d50.py` chỉ mở bản cũ khi được yêu cầu. Giữ toàn bộ macro/send/status của ba cầu nối và request lỗi/bị ngắt.

Các script sửa/chụp/kiểm tra dùng một lần, ảnh restart cũ và cặp request/response thành công đã được sao lưu có SHA-256. **Đã xóa 155 file rời sau khi người dùng đồng ý:** 25 script/ảnh dùng một lần và 65 cặp request/response thành công. Danh sách tại [CLEANUP_PLAN.md](CLEANUP_PLAN.md). Chỉ xóa trong `freecad_control`. Xem [HISTORY.md](HISTORY.md), ZIP `archive/cleanup_2026-11-03/session_cleanup.zip` và `cleanup_manifest.json`. Chỉ đọc lịch sử, không chạy lại script hoặc request đã lưu trong ZIP.

Lịch sử dọn ngày 02/11 vẫn ở `3D/Enclosure_Compact_Layout_D36/History_2026-11-02/Session_work_archive.zip`; không cần giải nén để mở CAD hiện tại.
