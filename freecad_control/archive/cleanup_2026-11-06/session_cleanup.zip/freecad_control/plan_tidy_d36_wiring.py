"""Guided cable groups for the existing D36; no pin/net or component changes."""
from pathlib import Path
import json, math
import numpy as np
from scipy.spatial import cKDTree
base=Path(__file__).resolve().parent.parent/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6'
folder=base/'Wiring_Tidy_2026-11-06'
plan=json.loads((folder/'routes_before_tidy.json').read_text())
by={r['name']:r for r in plan['routes']}
def setroute(name,middle):
 r=by[name];r['points']=[plan['ports'][r['source']]['point']]+middle+[plan['ports'][r['target']]['point']]
# Pair the long switched 5 V legs under the SD, on opposite sides of the lower post.
setroute('Boost_To_Switch',[[6,-2.4,91],[1,1.5,77],[-.5,2,72.5],[-2.5,2.5,68],[-2.5,2.5,65],[-2.5,3.25,63.5],[-2.5,3.25,27],[-5.5,0,21.5],[-5.5,0,12]])
setroute('Switch_To_ESP',[[5.5,0,12],[5.5,0,21.5],[-1.25,3.25,27],[-1.25,3.25,63.5],[-1.25,4,65],[-6.5,4,70.8],[-5.123,6.5,73.5],[-5.123,6.5,75.403]])
setroute('Battery_Positive',[[-4,3.275926,60.5],[-4,3.275926,64.5],[-8.8,0,67],[-8.8,0,88],[-9,-2.4,91]])
setroute('Battery_Negative',[[4,3.275926,60.5],[4,3.275926,64.5],[-6.7,0,67],[-6.7,0,88],[-6,-2.4,91]])
setroute('Boost_Ground',[[9,-2.4,91],[9,0,91],[7,0,80],[1,0,68.8],[1,5.9,68.8],[1,5.9,72],[-1.2,5.9,72],[-1.2,5.9,75.403],[-2.569,5.9,75.403]])
# SPI ribbon: identical plane and the same short departure/arrival lengths.
for name in ['SD_CS','SD_SCK','SD_MOSI','SD_MISO']:
 r=by[name];a=np.array(plan['ports'][r['source']]['point']);b=np.array(plan['ports'][r['target']]['point'])
 setroute(name,[[float(a[0]),6.7,75.403],[float(b[0]),7.926,71.5]])
# Keep the two SD supply leads below the ribbon, with separated crossing planes.
setroute('SD_Supply',[[-.015,5.9,75.403],[-.015,5.9,74],[-.015,3.5,73.4],[-.015,3.5,70.6],[3,3.5,70.6],[3,7.926,70.6]])
setroute('SD_Ground',[[-2.569,5.9,75.403],[-2.569,5.9,73.0],[-2.569,5,72],[5,5,72],[5,7.926,71.5]])
# Five microphone wires share an ordered corridor, then fan out at the breakout.
setroute('Mic_SD',[[2.539,6.7,90.403],[2.539,6.7,93],[3,4,96],[3,-8.2,96],[3,-9.3,99],[2.54,-11.3,100]])
setroute('Mic_SCK',[[5.093,6.7,90.403],[5.093,6.7,93],[4,4,96],[4,-8.2,96],[4,-9.3,109.8],[-2.54,-9.3,109.8],[-2.54,-11.3,108]])
setroute('Mic_WS',[[7.647,6.7,90.403],[7.647,6.7,93],[5,4,96],[5,-8.2,96],[5,-8.2,112],[0,-8.2,112],[0,-11.3,112],[0,-11.3,108]])
setroute('Mic_Supply',[[-.015,5.9,75.403],[-1.1,6.2,77.4],[-9.5,5.5,82.5],[-10.3,2.8,85.5],[-10.3,2.8,94],[1,4,96],[1,-8.2,96],[-2.54,-10.2,100],[-2.54,-11.3,100]])
setroute('Mic_Ground',[[-2.569,5.9,75.403],[-2.569,6.2,77.4],[-11.4,5.5,82.5],[-12.3,2.8,85.5],[-12.3,2.8,95.2],[2,4,97.3],[2,2,96],[2,-8.2,96],[1.2,-10.2,100],[.8,-11.3,100]])
setroute('Mic_Left_Channel',[[-.7,-11.5,100],[-1.4,-10.5,101.4],[1.1,-9.1,102.2],[1.1,-9.1,108],[2.54,-11.3,108]])
# Buttons share a straight corridor along the left PCB edge, spaced in Z.
for i,z in [(1,90.3333),(2,93.6667),(3,97)]:
 a=plan['ports']['ESP.GPIO'+str(i)]['point']
 setroute('Button_'+str(i),[[a[0],6.7,90.403],[a[0],6.7,z+.85],[-8.5,7.7,z+.85],[-8.5,12.6,z],[-5.3,12.6,z]])
setroute('Buttons_Ground',[[-3.9,5.9,75.403],[-4.5,7.8,77.5],[-8.5,8.6,80],[-8.5,8.6,84],[-8,12.5,85],[-5.3,13.435,87]])
for r in plan['routes']:
 r['length_mm']=sum(math.dist(a,b) for a,b in zip(r['points'],r['points'][1:]))
plan['routing_style']='Parallel grouped corridors, short fanouts; unchanged logical endpoints'
(folder/'routes.json').write_text(json.dumps(plan,indent=2))
# Mesh screening is diagnostic only; final checks use the Windows FreeCAD kernel.
tree=cKDTree(np.load(base/'Wiring_2026-11-06/surface_samples.npy'))
cloud={}
for r in plan['routes']:
 pts=np.concatenate([np.linspace(a,b,max(2,int(math.dist(a,b)/.07))) for a,b in zip(r['points'],r['points'][1:])])
 cloud[r['name']]=pts
 ds=tree.query(pts)[0]-r['diameter_mm']/2
 for end in [r['points'][0],r['points'][-1]]:ds[np.linalg.norm(pts-end,axis=1)<1.35]=999
 if ds.min()<.05:
  k=ds.argmin();print('OBSTACLE',r['name'],round(ds[k],3),np.round(pts[k],2).tolist())
for i,a in enumerate(plan['routes']):
 for b in plan['routes'][i+1:]:
  pts=cloud[b['name']];ds,ids=cKDTree(cloud[a['name']]).query(pts)
  shared={a['source'],a['target']}&{b['source'],b['target']}
  if a['net']==b['net']:
   for p in shared:ds[np.linalg.norm(pts-plan['ports'][p]['point'],axis=1)<1.1]=999
  k=ds.argmin();clear=ds[k]-(a['diameter_mm']+b['diameter_mm'])/2
  if clear<.07:print('WIRE',a['name'],b['name'],round(clear,3),np.round(pts[k],2).tolist())
print('Guided plan written')
