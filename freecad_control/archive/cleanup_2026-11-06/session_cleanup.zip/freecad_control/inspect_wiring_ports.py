import FreeCAD as App
import FreeCADGui as Gui
import Part
from pathlib import Path
import json
d=App.ActiveDocument
r={}
for name in ['MicroSD','IP5306','ESP32_C3']:
 pts=set()
 for e in d.getObject(name).Shape.Edges:
  try:c=e.Curve
  except TypeError:continue
  if isinstance(c,Part.Circle) and .25<c.Radius<1.3:
   pts.add(tuple(round(v,3) for v in (c.Center.x,c.Center.y,c.Center.z,c.Radius)))
 r[name]=sorted(pts)
for o in d.Objects:
 if o.Name in ['Front_half','Rear_half'] or o.Name.startswith(('Screw_','Nut_')):o.Visibility=False
Gui.activeDocument().activeView().viewRear()
Gui.activeDocument().activeView().fitAll()
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
Gui.activeDocument().activeView().saveImage(str(root/'freecad_control/wiring_ports.png'),1500,1100,'White')
result=r
