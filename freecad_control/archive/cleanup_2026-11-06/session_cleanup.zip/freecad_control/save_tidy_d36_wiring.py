import FreeCAD as App
import FreeCADGui as Gui
import Part
from pivy import coin
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
base=root/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6'
folder=base/'Wiring_Tidy_2026-11-06';path=base/'D36_Printed_Retention_35x25x6.FCStd'
d=App.ActiveDocument
assert Path(d.FileName)==path
report=json.loads((folder/'validation_preview.json').read_text())
assert report['status']=='ready_to_save' and not report['failures']
assert len([o for o in d.Objects if o.Name.startswith('Wire_')])==21
view=Gui.activeDocument().activeView()
d.Front_half.Visibility=False;d.Rear_half.Visibility=True
# Shaded displays the curved insulation clearly.
for o in d.Objects:
 if hasattr(o,'Shape') and 'Shaded' in o.ViewObject.listDisplayModes():o.ViewObject.DisplayMode='Shaded'
d.recompute()
back=App.Vector(.3,1,.22);back.normalize()
right=App.Vector(0,0,1)-back*back.z;right.normalize()
up=back.cross(right)
view.setCameraOrientation(App.Rotation(right,up,back,'ZXY').Q);view.fitAll()
camera=view.getCameraNode()
if isinstance(camera,coin.SoOrthographicCamera):camera.height.setValue(camera.height.getValue()*.72)
Gui.updateGui();d.save()
def payloads(z):
 xml=ET.fromstring(z.read('Document.xml'))
 out={}
 for obj in xml.findall('./ObjectData/Object'):
  prop=obj.find('./Properties/Property[@name="Shape"]')
  if prop is not None:
   part=prop.find('Part')
   if part is not None:out[obj.attrib['name']]=part.attrib['file']
 return out
with zipfile.ZipFile(folder/'D36_before_tidy.FCStd') as old,zipfile.ZipFile(path) as new:
 before={n:f for n,f in payloads(old).items() if not n.startswith('Wire_')};after=payloads(new)
 report['original_brep_payloads_byte_identical']=[n for n,f in before.items() if old.read(f)==new.read(after[n])]
 report['original_brep_payloads_reserialized']=[n for n in before if n not in report['original_brep_payloads_byte_identical']]
 readback=folder/'Saved_BRep_Readback';readback.mkdir(exist_ok=True)
 report['saved_brep_readback']={}
 for n in ['Front_half','Rear_half']+[o.Name for o in d.Objects if o.Name.startswith('Wire_')]:
  dest=readback/(n+'.brep');dest.write_bytes(new.read(after[n]));s=Part.read(str(dest))
  assert s.isValid() and len(s.Solids)==1,'Saved BRep invalid: '+n
  live=d.getObject(n).Shape;b=s.optimalBoundingBox(False,False)
  assert abs(s.Volume-live.Volume)<1e-5
  report['saved_brep_readback'][n]={'valid':True,'solids':1,'volume_mm3':s.Volume,'bbox_dimensions_mm':[b.XLength,b.YLength,b.ZLength]}
report['status']='saved_and_validated';report['object_count']=len(d.Objects)
report['cad_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
report['total_centerline_length_mm']=sum(float(o.CenterlineLength) for o in d.Objects if o.Name.startswith('Wire_'))
(folder/'validation.json').write_text(json.dumps(report,indent=2))
result={k:report[k] for k in ['status','object_count','wire_count','cad_sha256','total_centerline_length_mm','original_brep_payloads_reserialized']}
