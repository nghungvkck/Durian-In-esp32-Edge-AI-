import FreeCAD as App
from pathlib import Path
import json
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
d=App.ActiveDocument
out={}
for o in d.Objects:
 if hasattr(o,'Shape'):
  vs,ts=o.Shape.tessellate(.12)
  out[o.Name]={'vertices':[[v.x,v.y,v.z] for v in vs],'triangles':ts}
(root/'freecad_control/wiring_obstacles.json').write_text(json.dumps(out))
result={'objects':len(out)}
