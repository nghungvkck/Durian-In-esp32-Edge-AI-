import FreeCAD as App
import FreeCADGui as Gui
from pathlib import Path
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
folder=root/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6/Wiring_2026-11-06'
d=App.ActiveDocument;view=Gui.activeDocument().activeView()
view.saveImage(str(folder/'wiring_open_front.png'),1800,1000,'White')
d.Rear_half.Visibility=False
view.saveImage(str(folder/'wiring_components.png'),1800,1000,'White')
d.Rear_half.Visibility=True
result={'images':['wiring_open_front.png','wiring_components.png'],'geometry_changed':False}
