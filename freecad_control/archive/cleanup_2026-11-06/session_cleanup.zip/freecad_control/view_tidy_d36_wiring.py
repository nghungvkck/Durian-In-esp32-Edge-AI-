import FreeCAD as App
import FreeCADGui as Gui
from pathlib import Path
d=App.ActiveDocument
assert Path(d.FileName).name=='D36_Printed_Retention_35x25x6.FCStd'
for o in d.Objects:
 if o.Name in ['Front_half'] or o.Name.startswith(('Screw_','Nut_')):o.Visibility=False
 elif hasattr(o,'Shape'):
  o.Visibility=True
  if 'Shaded' in o.ViewObject.listDisplayModes():o.ViewObject.DisplayMode='Shaded'
view=Gui.activeDocument().activeView()
back=App.Vector(.3,1,.22);back.normalize();right=App.Vector(0,0,1)-back*back.z;right.normalize();up=back.cross(right)
view.setCameraOrientation(App.Rotation(right,up,back,'ZXY').Q);view.fitAll()
Gui.Selection.clearSelection();Gui.updateGui()
result={'view':'tidy harness open front; geometry unchanged; unsaved'}
