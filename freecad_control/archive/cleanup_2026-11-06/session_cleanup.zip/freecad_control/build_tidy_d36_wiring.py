"""Build the explicitly requested S3 reference harness in the canonical D36.
Run only through the Windows FreeCAD bridge. The C3 shape is a user-approved proxy.
"""
import FreeCAD as App
import FreeCADGui as Gui
import Part
from pathlib import Path
import json, math, shutil, hashlib, zipfile, xml.etree.ElementTree as ET, time
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
base=root/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6'
folder=base/'Wiring_Tidy_2026-11-06'
path=base/'D36_Printed_Retention_35x25x6.FCStd'
d=App.ActiveDocument
assert Path(d.FileName)==path,'Wrong active CAD'
plan=json.loads((folder/'routes.json').read_text())
assert len(plan['routes'])==21,'Incomplete routing plan'
backup=folder/'D36_before_tidy.FCStd'
if not backup.exists():shutil.copy2(path,backup)
source_names=[o.Name for o in d.Objects if hasattr(o,'Shape') and not o.Name.startswith('Wire_') and o.Name!='Wiring_D36_20261106']
assert len(source_names)==33
source={n:([v.Point for v in d.getObject(n).Shape.Vertexes],str(d.getObject(n).Placement),d.getObject(n).Shape.Volume,len(d.getObject(n).Shape.Faces),len(d.getObject(n).Shape.Edges)) for n in source_names}
for o in list(d.Objects):
 if o.Name.startswith('Wire_') or o.Name=='Wiring_D36_20261106':d.removeObject(o.Name)
V=App.Vector

def sweep(coords,diameter):
 pts=[V(*p) for p in coords]
 # Remove zero-length links while retaining the terminal coordinates.
 ps=[pts[0]]
 for p in pts[1:]:
  if (p-ps[-1]).Length>1e-5:ps.append(p)
 edges=[];current=ps[0]
 for i in range(1,len(ps)-1):
  p=ps[i];u=ps[i-1]-p;v=ps[i+1]-p
  lu=u.Length;lv=v.Length;u.normalize();v.normalize()
  theta=math.acos(max(-1,min(1,u.dot(v))))
  if theta>math.radians(175) or theta<math.radians(12):
   if (p-current).Length>1e-6:edges.append(Part.makeLine(current,p))
   current=p;continue
  t=min(.55,lu*.22,lv*.22)
  bis=u+v;bis.normalize()
  center=p+bis*(t/math.cos(theta/2))
  radius=t*math.tan(theta/2)
  toward=p-center;toward.normalize()
  middle=center+toward*radius
  a=p+u*t;b=p+v*t
  if (a-current).Length>1e-6:edges.append(Part.makeLine(current,a))
  edges.append(Part.Arc(a,middle,b).toShape());current=b
 if (ps[-1]-current).Length>1e-6:edges.append(Part.makeLine(current,ps[-1]))
 spine=Part.Wire(edges)
 profile=Part.Wire([Part.makeCircle(diameter/2,ps[0],ps[1]-ps[0])])
 shape=spine.makePipeShell([profile],True,False)
 assert shape.isValid() and len(shape.Solids)==1,'Invalid wire sweep'
 return shape,spine.Length

colors={'GND':(.12,.12,.14),'VBAT':(.9,.08,.1),'5V_RAW':(.95,.15,.08),'5V_SW':(.95,.32,.08),'3V3':(1.,.62,.05),
'SD_CS':(1.,.85,.1),'SD_SCK':(.1,.4,.95),'SD_MOSI':(.6,.18,.85),'SD_MISO':(.1,.7,.25),
'I2S_SD':(.05,.7,.65),'I2S_SCK':(.25,.45,.95),'I2S_WS':(.8,.25,.65),'KEY_1':(.95,.8,.15),'KEY_2':(.2,.75,.3),'KEY_3':(.55,.3,.9)}
group=d.addObject('App::DocumentObjectGroup','Wiring_D36_20261106');group.Label='D36 · S3 harness · grouped parallel routes'
for key,value in [('PinMapSource','firmware/README.md section 7, 2026-11-05'),('PhysicalPadOrder','UNVERIFIED: C3 shape reused for S3 per user; logical pad assignments only'),('SDSupply','3.3 V breakout confirmed by user'),('LED','GPIO7 reserved; no separate LED exists in this assembly')]:
 group.addProperty('App::PropertyString',key,'Wiring');setattr(group,key,value)
wire_objects=[]
for spec in plan['routes']:
 shape,length=sweep(spec['points'],spec['diameter_mm'])
 o=d.addObject('PartDesign::Feature','Wire_'+spec['name']);o.Shape=shape
 o.Label=spec['source']+' → '+spec['target']+' | '+spec['net']
 for key,value in [('SourceTerminal',spec['source']),('TargetTerminal',spec['target']),('Net',spec['net']),('ReferenceStatus','Logical connection / physical solder pad positions provisional')]:
  o.addProperty('App::PropertyString',key,'Wiring');setattr(o,key,value)
 o.addProperty('App::PropertyLength','InsulatedDiameter','Wiring');o.InsulatedDiameter=spec['diameter_mm']
 o.addProperty('App::PropertyLength','CenterlineLength','Wiring');o.CenterlineLength=length
 o.addProperty('App::PropertyVectorList','RoutePoints','Wiring');o.RoutePoints=[V(*p) for p in spec['points']]
 o.ViewObject.ShapeColor=colors[spec['net']];o.ViewObject.LineColor=colors[spec['net']];o.ViewObject.DisplayMode='Flat Lines'
 group.addObject(o);wire_objects.append(o)
esp=d.getObject('ESP32_C3');esp.Label='ESP32-S3 Super Mini | C3 geometry proxy approved 06/11/2026'
if 'BoardIdentity' not in esp.PropertiesList:esp.addProperty('App::PropertyString','BoardIdentity','Reference')
esp.BoardIdentity='ESP32-S3 Super Mini; unchanged C3 geometry/placement at user request; physical header order unverified'
d.recompute()
for n,sig in source.items():
 sh=d.getObject(n).Shape
 assert str(d.getObject(n).Placement)==sig[1] and abs(sh.Volume-sig[2])<1e-7 and len(sh.Faces)==sig[3] and len(sh.Edges)==sig[4]
 assert len(sh.Vertexes)==len(sig[0]) and all((a.Point-b).Length<1e-8 for a,b in zip(sh.Vertexes,sig[0])),'Source geometry changed: '+n
report={'status':'preview_validation','source_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'wire_count':len(wire_objects),'original_objects_unchanged':True,'wires':{},'failures':[], 'physical_pin_order_verified':False}
# Check each wire against each source object independently. Avoid assembly-wide Boolean operations.
def endpoint_owner(name):
 prefix=name.split('.')[0]
 return {'ESP':'ESP32_C3','BAT':'Battery','SW':'SW1_Terminals','IP':'IP5306','SD':'MicroSD','MIC':'Mic_Pads','KEY':'Key_Pads'}[prefix]
for spec,o in zip(plan['routes'],wire_objects):
 shape=o.Shape
 row={'valid':shape.isValid(),'solids':len(shape.Solids),'length_mm':float(o.CenterlineLength),'collisions':[],'minimum_shell_clearance_mm':999}
 allowed={}
 for k in ['source','target']:
  terminal=spec[k];p=V(*plan['ports'][terminal]['point']);ball=Part.makeSphere(1.3,p)
  owner=endpoint_owner(terminal)
  for n in [owner]+({'Mic_Pads':['Mic_PCB'],'Key_Pads':['Key_PCB']}.get(owner,[])):
   allowed[n]=ball if n not in allowed else allowed[n].fuse(ball)
 for name in source_names:
  obstacle=d.getObject(name).Shape
  distance=shape.distToShape(obstacle)[0]
  if name in ['Front_half','Rear_half']:row['minimum_shell_clearance_mm']=min(row['minimum_shell_clearance_mm'],distance)
  if distance>1e-6:continue
  check=shape.cut(allowed[name]) if name in allowed else shape
  if check.isNull():continue
  # IP5306 consists of faces: area and distance matter as well as volume.
  overlap=check.common(obstacle)
  vol=abs(overlap.Volume);area=overlap.Area
  bad=vol>1e-5 if obstacle.Solids else area>1e-5
  if bad:
   collision={'object':name,'volume_mm3':vol,'area_mm2':area};row['collisions'].append(collision)
   report['failures'].append({'wire':o.Name,**collision})
 report['wires'][o.Name]=row
 (folder/'validation_preview.json').write_text(json.dumps(report,indent=2))
# Independently verify that different wires do not occupy the same insulated volume,
# except within the shared terminal envelope of the same electrical net.
report['wire_wire_collisions']=[]
for i,(s1,o1) in enumerate(zip(plan['routes'],wire_objects)):
 for s2,o2 in list(zip(plan['routes'],wire_objects))[i+1:]:
  if not o1.Shape.BoundBox.intersect(o2.Shape.BoundBox):continue
  if o1.Shape.distToShape(o2.Shape)[0]>1e-6:continue
  check=o1.Shape
  shared=set([s1['source'],s1['target']])&set([s2['source'],s2['target']])
  if s1['net']==s2['net']:
   for name in shared:check=check.cut(Part.makeSphere(1.1,V(*plan['ports'][name]['point'])))
  overlap=check.common(o2.Shape)
  if abs(overlap.Volume)>1e-5:
   issue={'wires':[o1.Name,o2.Name],'volume_mm3':abs(overlap.Volume)}
   report['wire_wire_collisions'].append(issue);report['failures'].append(issue)
for name in ['Front_half','Rear_half']:
 shape=d.getObject(name).Shape;b=shape.optimalBoundingBox(False,False)
 assert shape.isValid() and len(shape.Solids)==1 and abs(b.XLength-36)<.01 and abs(b.ZLength-146)<.01
report['source_shells_valid']=True
# Show interior at installed coordinates. The front half is hidden only for inspection.
for o in d.Objects:
 if hasattr(o,'ViewObject'):o.Visibility=True
d.Front_half.Visibility=False
for o in d.Objects:
 if o.Name.startswith(('Screw_','Nut_')):o.Visibility=False
Gui.Selection.clearSelection();view=Gui.activeDocument().activeView();view.viewRear()
q=view.getCameraOrientation();view.setCameraOrientation(App.Rotation(V(0,1,0),90).multiply(q).Q)
view.fitAll()
report['status']='validation_failed' if report['failures'] else 'ready_to_save'
(folder/'validation_preview.json').write_text(json.dumps(report,indent=2))
result={'status':report['status'],'wires':len(wire_objects),'failures':report['failures'],'saved':False}
