import FreeCAD as App
import FreeCADGui as Gui
import json
from pathlib import Path
d=App.ActiveDocument
def bb(s):
 b=s.BoundBox
 return [round(v,4) for v in (b.XMin,b.YMin,b.ZMin,b.XMax,b.YMax,b.ZMax)]
r={}
for o in d.Objects:
 if hasattr(o,'Shape'):
  r[o.Name]={'label':o.Label,'bbox':bb(o.Shape),'solids':len(o.Shape.Solids),'faces':len(o.Shape.Faces),'placement':str(o.Placement)}
  if o.Name in ['ESP32_C3','IP5306','MicroSD','Mic_Pads','Key_Pads','SW1_Terminals']:
   r[o.Name]['parts']=[{'bbox':bb(s),'vol':round(s.Volume,4)} for s in (o.Shape.Solids or o.Shape.Faces)]
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
(root/'freecad_control/wiring_inspection.json').write_text(json.dumps(r,indent=2))
d.Front_half.Visibility=False
Gui.activeDocument().activeView().viewAxonometric()
Gui.activeDocument().activeView().fitAll()
Gui.activeDocument().activeView().saveImage(str(root/'freecad_control/wiring_before.png'),1500,1100,'White')
result=r
