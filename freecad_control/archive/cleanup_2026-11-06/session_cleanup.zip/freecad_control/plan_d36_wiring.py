"""Route reference harness around sampled CAD surfaces; final BRep validation is separate."""
import json, math, heapq, itertools, time, sys
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
root=Path(__file__).resolve().parent
cad=root.parent/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6/Wiring_2026-11-06'
raw=json.loads((root/'wiring_obstacles.json').read_text())
if (cad/'surface_samples.npy').exists():
 points=np.load(cad/'surface_samples.npy')
 tree=cKDTree(points)
else:
 cloud=[]
 for name,data in raw.items():
  v=np.array(data['vertices']);t=v[np.array(data['triangles'])]
  size=np.ceil(np.max(np.linalg.norm(t-np.roll(t,1,axis=1),axis=2),axis=1)/.38).astype(int)
  for n in np.unique(size):
   tt=t[size==n]; n=max(1,int(n))
   uv=np.array([(i/n,j/n) for i in range(n+1) for j in range(n+1-i)])
   for batch in np.array_split(tt,max(1,math.ceil(len(tt)*len(uv)/200000))):
    samples=batch[:,None,0]+uv[None,:,0,None]*(batch[:,None,1]-batch[:,None,0])+uv[None,:,1,None]*(batch[:,None,2]-batch[:,None,0])
    cloud.append(samples.reshape(-1,3))
 points=np.concatenate(cloud)
 points=np.unique(np.round(points/.14).astype(np.int16),axis=0)*.14
 print('Surface samples',len(points),flush=True)
 tree=cKDTree(points)
 np.save(cad/'surface_samples.npy',points)
step=.5
lo=np.array([-16.,-16.,12.])
shape=(65,65,201)
grid=np.stack(np.meshgrid(*[np.arange(n) for n in shape],indexing='ij'),-1).reshape(-1,3)
xyz=lo+grid*step
if (cad/'routing_grid.npz').exists():
 dist=np.load(cad/'routing_grid.npz')['distance']
else:
 dist=tree.query(xyz,workers=-1)[0].reshape(shape)
 # Fill shell material by parity along Y, so a free anchor cannot land inside a rib.
 for shell in ['Front_half','Rear_half']:
  data=raw[shell];vv=np.array(data['vertices']);tt=vv[np.array(data['triangles'])]
  aa=tt[:,0];u=tt[:,1]-aa;v=tt[:,2]-aa
  det=u[:,0]*v[:,2]-u[:,2]*v[:,0]
  use=np.abs(det)>1e-10;aa=aa[use];u=u[use];v=v[use];det=det[use]
  for ix in range(shape[0]):
   x=lo[0]+ix*step+1.23e-6
   for iz in range(shape[2]):
    z=lo[2]+iz*step+3.21e-6
    dx=x-aa[:,0];dz=z-aa[:,2]
    al=(dx*v[:,2]-dz*v[:,0])/det;be=(u[:,0]*dz-u[:,2]*dx)/det
    hit=(al>=0)&(be>=0)&(al+be<=1)
    ys=np.unique(np.round((aa[:,1]+al*u[:,1]+be*v[:,1])[hit],5))
    yy=lo[1]+np.arange(shape[1])*step
    parity=np.searchsorted(ys,yy,side='right')%2==1
    dist[ix,parity,iz]=0
 np.savez_compressed(cad/'routing_grid.npz',distance=dist)
 
inside=(xyz[:,0]**2+xyz[:,1]**2<15.5**2).reshape(shape)
# No grid node may enter a source solid through its conservatively blocked surface.
used=[]
ports={}
def port(name,p,normal,anchor=1.6):
 p=np.array(p,dtype=float);normal=np.array(normal,dtype=float)
 ports[name]={'point':p.tolist(),'anchor':(p+normal*anchor).tolist()}
# The C3 geometric proxy has 8 pads per row. GPIO names are logical assignments,
# not a claim that its physical pad order matches the user's S3 board.
xs=[-5.123,-2.569,-.015,2.539,5.093,7.647,10.2,12.754]
for i,x in enumerate(xs):port('ESP.GPIO'+str(i+1),[x,5.2,90.403],[0,1,0])
for signal,x in zip(['5V','GND','3V3','GPIO13','GPIO12','GPIO11','GPIO10','GPIO9'],xs):
 port('ESP.'+signal,[x,5.2,75.403],[0,1,0])
for signal,x in zip(['CS','SCK','MOSI','MISO','VCC','GND'],[-5,-3,-1,1,3,5]):
 port('SD.'+signal,[x,7.926,69.748],[0,0,1])
for signal,x,z in [('B+',-9,91),('B-',-6,91),('5V',6,91),('GND',9,91)]:
 port('IP.'+signal,[x,-4,z],[0,1,0])
port('BAT.+',[-4,2.175926,60.5],[0,1,0],1.1);port('BAT.-',[4,2.175926,60.5],[0,1,0],1.1)
port('SW.IN',[-3,0,12.0],[-1,0,0],2.5);port('SW.OUT',[3,0,12.0],[1,0,0],2.5)
for signal,x,z in [('VDD',-2.54,100),('GND',0,100),('SD',2.54,100),('SCK',-2.54,108),('WS',0,108),('LR',2.54,108)]:
 port('MIC.'+signal,[x,-12.165,z],[0,1,0])
for signal,z in zip(['GND','K1','K2','K3'],[87,90.3333,93.6667,97]):
 port('KEY.'+signal,[-5.3,11.835,z],[0,1,0])
specs=[]
def add(name,a,b,net,kind='signal'):
 specs.append(dict(name=name,source=a,target=b,net=net,diameter_mm=.9 if kind=='power' else .65))
add('Battery_Positive','BAT.+','IP.B+','VBAT','power')
add('Battery_Negative','BAT.-','IP.B-','GND','power')
add('Boost_To_Switch','IP.5V','SW.IN','5V_RAW','power')
add('Switch_To_ESP','SW.OUT','ESP.5V','5V_SW','power')
add('Boost_Ground','IP.GND','ESP.GND','GND','power')
for sig,gpio in [('CS',13),('SCK',12),('MOSI',11),('MISO',10)]:add('SD_'+sig,'ESP.GPIO'+str(gpio),'SD.'+sig,'SD_'+sig)
add('SD_Supply','ESP.3V3','SD.VCC','3V3')
add('SD_Ground','ESP.GND','SD.GND','GND')
for sig,gpio in [('SD',4),('SCK',5),('WS',6)]:add('Mic_'+sig,'ESP.GPIO'+str(gpio),'MIC.'+sig,'I2S_'+sig)
add('Mic_Supply','ESP.3V3','MIC.VDD','3V3')
add('Mic_Ground','ESP.GND','MIC.GND','GND')
add('Mic_Left_Channel','MIC.GND','MIC.LR','GND')
for i in (1,2,3):add('Button_'+str(i),'ESP.GPIO'+str(i),'KEY.K'+str(i),'KEY_'+str(i))
add('Buttons_Ground','ESP.GND','KEY.GND','GND')
neighbors=[(a,b,c) for a,b,c in itertools.product([-1,0,1],repeat=3) if (a,b,c)!=(0,0,0)]
def line_points(a,b,spacing=.2):
 a=np.array(a);b=np.array(b);n=max(2,int(np.linalg.norm(b-a)/spacing)+2)
 return np.linspace(a,b,n)
def simplify(path,clear,wiretree,allow):
 def good(a,b):
  ps=line_points(a,b)
  if tree.query(ps)[0].min()<clear:return False
  if wiretree is not None:
   ds=wiretree.query(ps)[0]
   if np.any(ds<.95):return False
  return True
 result=[path[0]];i=0
 while i<len(path)-1:
  j=len(path)-1
  while j>i+1 and not good(path[i],path[j]):j-=1
  result.append(path[j]);i=j
 return result
checkpoint={r['name']:r for r in json.loads((cad/'routes.json').read_text())['routes']} if '--resume' in sys.argv else {}
routes=[]
for spec in specs:
 if spec['name'] in checkpoint:
  routes.append(checkpoint[spec['name']]);continue
 radius=spec['diameter_mm']/2
 # .38 mm surface sampling; safety margin includes discretization.
 clear=radius+.26
 free=(dist>=clear)&inside
 a=np.array(ports[spec['source']]['anchor']);b=np.array(ports[spec['target']]['anchor'])
 allow=[np.array(ports[spec[k]]['point']) for k in ['source','target']]
 wirepoints=[]
 active_ports={sp[k] for sp in specs for k in ['source','target']}
 for terminal in active_ports-{spec['source'],spec['target']}:
  wirepoints.append(line_points(ports[terminal]['point'],ports[terminal]['anchor']))
 for old in routes:
  ps=np.concatenate([line_points(x,y) for x,y in zip(old['points'],old['points'][1:])])
  # Branches can merge only near a shared terminal on the same net.
  if old['net']==spec['net']:
   mask=np.ones(len(ps),bool)
   for pp in allow:mask&=np.linalg.norm(ps-pp,axis=1)>3.2
   ps=ps[mask]
  wirepoints.append(ps)
 wiretree=cKDTree(np.concatenate(wirepoints)) if wirepoints else None
 if wiretree is not None:
  wd=wiretree.query(xyz,workers=-1)[0].reshape(shape)
  free&=wd>radius+.45+.12
 def nearest(p):
  q=np.rint((p-lo)/step).astype(int)
  cand=[]
  for delta in itertools.product(range(-3,4),repeat=3):
   k=tuple(q+delta)
   if all(0<=k[i]<shape[i] for i in range(3)) and free[k]:
    pos=lo+np.array(k)*step
    segment=line_points(p,pos)
    if tree.query(segment)[0].min()>=clear-.04 and (wiretree is None or wiretree.query(segment)[0].min()>.95):
     cand.append((np.linalg.norm(pos-p),k))
  if not cand:raise RuntimeError('No free anchor '+str(p)+' '+spec['name'])
  return min(cand)[1]
 start=nearest(a);goal=nearest(b)
 def h(k):return math.dist(k,goal)
 queue=[(h(start),0,start)];cost={start:0};parent={};found=False
 while queue:
  _,g,k=heapq.heappop(queue)
  if g>cost.get(k,1e99)+1e-8:continue
  if k==goal:found=True;break
  for off in neighbors:
   nxt=tuple(k[i]+off[i] for i in range(3))
   if not all(0<=nxt[i]<shape[i] for i in range(3)) or not free[nxt]:continue
   # Prevent diagonal corner cutting.
   if any(not free[tuple(nxt[j] if j==i else k[j] for j in range(3))] for i in range(3) if off[i]):continue
   ng=g+math.sqrt(sum(t*t for t in off))+.025/(float(dist[nxt])+.1)
   if ng<cost.get(nxt,1e99):
    cost[nxt]=ng;parent[nxt]=k;heapq.heappush(queue,(ng+h(nxt),ng,nxt))
 if not found:raise RuntimeError('No path '+spec['name'])
 path=[goal]
 while path[-1]!=start:path.append(parent[path[-1]])
 path=[a.tolist()]+[(lo+np.array(k)*step).tolist() for k in path[::-1]]+[b.tolist()]
 path=simplify(path,clear,wiretree,allow)
 path=[ports[spec['source']]['point']]+path+[ports[spec['target']]['point']]
 spec.update(points=path,length_mm=round(sum(math.dist(x,y) for x,y in zip(path,path[1:])),3))
 routes.append(spec)
 print(spec['name'],spec['length_mm'],'mm',len(path),'points',flush=True)
 (cad/'routes.json').write_text(json.dumps({'ports':ports,'routes':routes,'physical_pin_order_verified':False},indent=2))
print('DONE',len(routes),flush=True)
