import FreeCAD as App
import json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
d=App.ActiveDocument
src=App.openDocument(str(root/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6/Wiring_2026-11-06/D36_before_wiring.FCStd'))
r={}
for o in src.Objects:
 n=d.getObject(o.Name)
 b1=o.Shape.optimalBoundingBox(False,False);b2=n.Shape.optimalBoundingBox(False,False)
 r[o.Name]={'volume_delta':n.Shape.Volume-o.Shape.Volume,'placement_equal':str(n.Placement)==str(o.Placement),'bbox_delta':[getattr(b2,k)-getattr(b1,k) for k in ['XMin','YMin','ZMin','XMax','YMax','ZMax']],'faces':[len(o.Shape.Faces),len(n.Shape.Faces)]}
App.closeDocument(src.Name);App.setActiveDocument(d.Name)
result=r
