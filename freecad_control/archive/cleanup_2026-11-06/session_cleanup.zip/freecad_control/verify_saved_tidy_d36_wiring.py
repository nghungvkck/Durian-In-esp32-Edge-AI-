import FreeCAD as App
import Part
from pathlib import Path
import json,zipfile,xml.etree.ElementTree as ET,hashlib
root=Path(r'D:\Hoc_tap_Sinh_Vien\Kien_thu_AI\Project\Duration_edge_ai')
base=root/'3D/Enclosure_Compact_Layout_D36/Printed_Retention_35x25x6';folder=base/'Wiring_Tidy_2026-11-06'
report=json.loads((folder/'validation.json').read_text())
def data(z):
 xml=ET.fromstring(z.read('Document.xml'));out={}
 for o in xml.findall('./ObjectData/Object'):
  prop=o.find('./Properties/Property[@name="Shape"]/Part')
  if prop is not None:out[o.attrib['name']]=(prop.attrib['file'],o.find('./Properties/Property[@name="Placement"]/PropertyPlacement').attrib)
 return out
comparisons={}
with zipfile.ZipFile(folder/'D36_before_tidy.FCStd') as old,zipfile.ZipFile(base/'D36_Printed_Retention_35x25x6.FCStd') as new:
 before={n:v for n,v in data(old).items() if not n.startswith('Wire_')};after=data(new)
 for name,(entry,placement) in before.items():
  shapes=[]
  for kind,z,file in [('before',old,entry),('after',new,after[name][0])]:
   p=folder/'Saved_BRep_Readback'/('compare_'+kind+'.brep');p.write_bytes(z.read(file));shapes.append(Part.read(str(p)))
  a,b=shapes
  assert len(a.Vertexes)==len(b.Vertexes) and len(a.Edges)==len(b.Edges) and len(a.Faces)==len(b.Faces)
  vd=max((x.Point-y.Point).Length for x,y in zip(a.Vertexes,b.Vertexes))
  ed=max(abs(x.Length-y.Length) for x,y in zip(a.Edges,b.Edges))
  fd=max(abs(x.Area-y.Area) for x,y in zip(a.Faces,b.Faces))
  pd=max(abs(float(placement[k])-float(after[name][1][k])) for k in placement)
  assert vd<1e-7 and ed<1e-7 and fd<1e-7 and pd<1e-9 and abs(a.Volume-b.Volume)<1e-6
  comparisons[name]={'vertices_max_delta_mm':vd,'edges_max_length_delta_mm':ed,'faces_max_area_delta_mm2':fd,'volume_delta_mm3':abs(a.Volume-b.Volume),'placement_max_numeric_delta':pd}
report['saved_original_geometry_comparison']=comparisons
report['saved_original_geometry_comparison_count']=len(comparisons)
(folder/'validation.json').write_text(json.dumps(report,indent=2))
result={'source_objects_compared':len(comparisons),'all_passed':True,'cad_sha256':report['cad_sha256']}
